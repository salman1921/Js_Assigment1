var quizData = [
    {
      question: "What is 2 + 2?",
      choices: ["3", "4", "5", "6"],
      correct: "4"
    },
    {
      question: "What is the capital of France?",
      choices: ["Madrid", "Rome", "Paris", "Berlin"],
      correct: "Paris"
    },
    {
    question: "how many days in febuary",
            choices: ["30","29","31","28"],
            correct: "28"
    }
    // Add more questions here
  ];
  
  var quiz = document.getElementById('quiz');
  var questionContainer = document.getElementById('question-container');
  var choicesContainer = document.getElementById('choices');
  var resultContainer = document.getElementById('result');
  var timer = document.getElementById('timer');
  var timeElement = document.getElementById('time');
  
  var currentQuestion = 0;
  var score = 0;
  var time = 0;
  
  function loadQuestion() {
    if (currentQuestion < quizData.length) {
      questionContainer.innerHTML = quizData[currentQuestion].question;
      choicesContainer.innerHTML = '';
  
      quizData[currentQuestion].choices.forEach(function (choice) {
        var button = document.createElement('button');
        button.textContent = choice;
        button.className = 'choice';
        button.addEventListener('click', checkAnswer);
        choicesContainer.appendChild(button);
      });
  
      startTimer();
    } else {
      showResult();
    }
  }
  
  function checkAnswer(e) {
    var userChoice = e.target.textContent;
    var correctAnswer = quizData[currentQuestion].correct;
  
    if (userChoice === correctAnswer) {
      score++;
    }
  
    currentQuestion++;
    loadQuestion();
  }
  
  function startTimer() {
    time = 0;
    var interval = setInterval(() => {
      time++;
      timeElement.textContent = time;
    }, 1000);
  
    setTimeout(() => {
      clearInterval(interval);
      timeElement.textContent = time;
      currentQuestion++;
      loadQuestion();
    }, 20000); // 20 seconds timer
  }
  
  function showResult() {
    quiz.style.display = 'none';
    resultContainer.textContent = `You got ${score} out of ${quizData.length} questions correct!`;
  }
  
  loadQuestion();
  
