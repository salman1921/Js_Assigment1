// FUNCTION
// 1. Write a function that displays current date & time in your
// browser.


// var date = new Date()

// console.log(date);


// 2. Write a function that takes first & last name and then it
// greets the user using his full name.

// function greet() {

//   var firstname = prompt("Enter first name");
//   var lastname = prompt("Enter last name");
//   var fullname = firstname + " " +  lastname;
  
//   console.log(fullname);
// }
// greet()

// 3. Write a function that adds two numbers (input by user)
// and returns the sum of two numbers.


// function Sum() {

//     var Value1 = +prompt("Enter first num");
//     var Value2 = +prompt("Enter Second num");
//     var Calc = Value1 +  Value2;
    
//     console.log(Calc);
//   }


// 4. Calculator:
// Write a function that takes three arguments num1, num2
// & operator & compute the desired operation. Return and
// show the desired result in your browser.


// function multiplicationTable(tableNumber, tableLength) {
  
//     for (var i = 1; i <= tableLength; i++) {
//     document.write(tableNumber + "x" + i + "=" + tableNumber * i + "<br>");
//   }
// }

// var tableNumber = +prompt("Enter a number to generate table...");
// var tableLength = +prompt("Enter table length..");

// multiplicationTable(tableNumber, tableLength);



// function square(x) {

//     return x * x;
//   }
  


//   const result = square(5);
//   console.log(result); 


// 6. Write a function that computes factorial of a number.

// function factorial(x) {

//     return x =! x;
//   }
  


//   const result = factorial(234);
//   console.log(result); 

function factorialRecursive(n) {
    
    
    if (n === 0 || n === 1) {
      return 1;
    } else {
      return n * factorialRecursive(n - 1);
    }
  }
  
  // Example usage:
  const result = factorialRecursive(5);
  console.log(result); // Output will be 120
  